

average.peak <-
function(base, numbers, startmsec, endmsec, env=.GlobalEnv, baseline=-200, total.length=1200, peaktype="max")
	{	
		datall=NULL		
			
		#### creo la funzione msectopoints
		## dati 1) il tempo iniziale 2) il tempo finale e 3) la lunghezza globale in punti converte l'argomento "a" da msec a punti
		msectopoints=function(a,lengthsegment, baseline, total.length){
		x=((a-(baseline))*lengthsegment)/(total.length+abs(baseline))
		return(x)}
		####
		for (i in 1:length(numbers))
		{
		average.temp=eval(parse(file="", text=paste(base,numbers[i], sep="")),env=env)
		Subject_name=comment(eval(parse(file="", text=paste(base,numbers[i], sep="")),env=env))
		average.temp=apply(average.temp[round(msectopoints(startmsec,dim(average.temp)[1],baseline, total.length)):round(msectopoints(endmsec,dim(average.temp)[1],baseline, total.length)),],2, eval(parse(file="", text=peaktype)))
		average.temp=data.frame(t(average.temp))
		average.temp$Subject=numbers[i]
		average.temp$Subject_name=Subject_name
		datall=rbind(datall, average.temp)
		}
		rownames(datall)=1:dim(datall)[1]
		return(datall)
		}

