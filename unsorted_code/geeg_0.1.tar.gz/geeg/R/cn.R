cn <-
function(x){as.matrix(colnames(x))}

