eeg <-
function(e1,main=NULL, smo=0.5 , col="black", startmsec=-200, endmsec=1000, yrev=TRUE, interval=c(startmsec, endmsec), step=200, verticals=NULL, horizontals=NULL, x.axis="default", ylim="default", lwd=1, lty=1, cex.main=1, cex.xaxis=0.8, cex.yaxis=1, y.axis="default", frame.plot=TRUE, xaxis0=FALSE, xtick.l="default",xticks="default", yaxis0=FALSE, yaxis0.origin=0, ytick.l="default", y.axis.step=2,  yticks="default"){
	
	
	lengthwhole=length(e1)
	msectopoints=function(a,lengthsegment){
	x=((a-(startmsec))*lengthsegment)/(endmsec+abs(startmsec))
	return(x)}
	
	
	startpoint=msectopoints(interval[1], lengthwhole)
	endpoint=msectopoints(interval[2], lengthwhole)
	
	
	vet=seq(interval[1], interval[2], step)
	
	if (x.axis[1]!="default"){
		vet=x.axis
		}
	
	#AGGIUNGI UNA CONDIZIONE IF: nel caso in cui il vettore specificato è particolarmente corto allora cambia la scala (a passi da 100 invece che a passi da 200.)
	
	
	
	temp0=msectopoints(0, lengthwhole)
	vet2=msectopoints(vet, lengthwhole)
	vet.names=paste(vet) # vet sarebbero le labels del nuovo asse

	maxe1=max(e1)
	mine1=min(e1)
	
	
	if (ylim[1]=="default"){
		ylim=sort(range(c(-6,6,maxe1, mine1)))
		}
	else {
		ylim=ylim
	}

	
		
		plot(smooth.spline(e1, spar=smo), type="l", ylim=sort(ylim), col=col,lwd=lwd, main=main, yaxt="n", xaxt="n",xlim=c(startpoint, endpoint), ylab="",xlab="", lty=lty, cex.axis=cex.yaxis, frame.plot=frame.plot, cex.main=cex.main)
	
	
	if(xtick.l=="default"){
		xtick.l=sum(abs(ylim)/40)
		}
		
	
	
	if (xaxis0==FALSE){
		axis(1,vet2, paste(vet), cex.axis=cex.xaxis)
		abline(h=0, lty="longdash")
		segments(temp0,-0.5,temp0,0.5, lty=1.5)
		}
		
	if (xticks[1]=="default"){
	xticks=vet	
	}
		
	if (xaxis0==TRUE){
		xticks=msectopoints(xticks, length(e1))	
		segments(xticks, -xtick.l, xticks, +xtick.l, lty=1.5)
		abline(h=0)
		}
	
	if (yaxis0==FALSE){
	axis(2,seq(ylim[1], ylim[2], y.axis.step), seq(ylim[1], ylim[2], y.axis.step), cex.axis=cex.xaxis)
	}
	
	 if(ytick.l=="default"){
	 	ytick.l=length(e1)/40 #
	 }
	
	if (yticks[1]=="default") {
		yticks=seq(ylim[1], ylim[2], y.axis.step)
	}
	
	if (yaxis0==TRUE){
	
		abline(v=msectopoints(yaxis0.origin, length(e1)), lty=1.5)
		segments(msectopoints(yaxis0.origin, length(e1))-ytick.l, yticks, msectopoints(yaxis0.origin, length(e1))+ytick.l, yticks )
	}
	
	

	
	# draw vertical lines (expressed in msec and authomatically converted in points)
	for (i in 1:length(verticals)){
		x=msectopoints(verticals[i], lengthwhole)
		abline(v=x)
		}	
	#draw horizontal lines (expressed in microvolts)
	for (i in 1:length(horizontals)){
		x=(horizontals[i])
		abline(h=x)
	}	
}

