average.latency <-
function(base, numbers, startmsec, endmsec, env=.GlobalEnv, baseline=-200, total.length=1200, peaktype="max")
	{	
		datall=NULL		
			
		#### creo la funzione msectopoints
		## dati 1) il tempo iniziale 2) il tempo finale e 3) la lunghezza globale in punti converte l'argomento "a" da msec a punti
		msectopoints=function(a,lengthsegment, baseline, total.length){
		x=((a-(baseline))*lengthsegment)/(total.length+abs(baseline))
		return(x)}
		
		pointstomsec=function(a, lengthsegment, baseline, total.length){
			x=(((total.length+abs(baseline))*a)/lengthsegment)-abs(baseline)
			return(x)
			}
		####
		for (i in 1:length(numbers))
		{
		average.temp=eval(parse(file="", text=paste(base,numbers[i], sep="")),env=env)
		rownames(average.temp)=1:dim(average.temp)[1]
		Subject_name=comment(eval(parse(file="", text=paste(base,numbers[i], sep="")),env=env))
		average.temp.peak=apply(average.temp[round(msectopoints(startmsec,dim(average.temp)[1],baseline, total.length)):round(msectopoints(endmsec,dim(average.temp)[1],baseline, total.length)),],2, eval(parse(file="", text=peaktype)))
		
		peak.pnts=NULL
		for (k in 1:length(average.temp)){
			peak.pnts.temp=as.numeric(rownames(average.temp[average.temp[,k]==average.temp.peak[k],]))
			peak.pnts[k]=peak.pnts.temp[peak.pnts.temp>=round(msectopoints(startmsec,dim(average.temp)[1],baseline, total.length))&peak.pnts.temp<=round(msectopoints(endmsec,dim(average.temp)[1],baseline, total.length))][1]
			}
			
		peak.msec=pointstomsec(peak.pnts, dim(average.temp)[1], baseline, total.length)
		average.temp.lat=data.frame(t(peak.msec))
		names(average.temp.lat)=names(average.temp)#ripristino i nomi degli elettrodi, persi nei pasaggi
		average.temp.lat$Subject=numbers[i]
		average.temp.lat$Subject_name=Subject_name
		datall=rbind(datall, average.temp.lat)
		}
		rownames(datall)=1:dim(datall)[1]
		return(datall)
		}

